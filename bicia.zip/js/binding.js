let Binding=function(){
    this.updateResult=function(points){
        $('#points').html(points);
    };
    this.updateClock=function(time){
        $('#time').html(time);
    };
    this.unlockLevelAndType=function(){
        $('#level').removeAttr('disabled');
        $('#type').removeAttr('disabled');
    };
    this.blockLevelAndType=function(){
        $('#level').attr('disabled', 'disabled');
        $('#type').attr('disabled', 'disabled');
    };
};

