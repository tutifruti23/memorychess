$(function(){
    console.log(easyFens.length);
    console.log(mediumFens.length);
    console.log(hardFens.length);
    let gameMethods=new GameMethods('board');
    let game=new Game();
    let binding = new Binding();
    /*game.startGame(true,{
        play:function() {
            gameMethods.endlessGenerate();
        }
    });*/
    let onTime=function(time){
        binding.updateClock(time);
    };
    let onCloseToEnd=function(){
        console.log("koniec czasu");
    };
    let onEnd=function(){
        gameMethods.blockBoard();
        binding.unlockLevelAndType()
    };
    let onStart=function(){
        binding.blockLevelAndType();
    };
    $("#newGame").on('click',function(){
        onEnd();
        game.newGame();
    });
    $("#startGame").on('click',function(){
        gameMethods.points=0;
        game.startGame(game.type==0,{
            time:game.type*1000,
            onTime:onTime,
            timeCloseEnd:10000,
            onCloseToEnd:onCloseToEnd,
            interval:1000,
            onStart:onStart,
            onEnd:onEnd,
            play:function() {
                gameMethods.endlessGenerate(game.level);
            }
        });
    });
    $('#level').on('change',function(){
        game.level=this.value;
    });
    $('#type').on('change',function(){
        game.type=this.value;
    });

});